var classParma__Polyhedra__Library_1_1Congruences__Reduction =
[
    [ "Congruences_Reduction", "classParma__Polyhedra__Library_1_1Congruences__Reduction.html#ac1c1301f7ca50550e48eb2e0e57528d0", null ],
    [ "~Congruences_Reduction", "classParma__Polyhedra__Library_1_1Congruences__Reduction.html#a1b6e413a75c138ef87cc373df0d25194", null ],
    [ "product_reduce", "classParma__Polyhedra__Library_1_1Congruences__Reduction.html#a302c20124e5caa73cb5a860a57d6be5e", null ]
];