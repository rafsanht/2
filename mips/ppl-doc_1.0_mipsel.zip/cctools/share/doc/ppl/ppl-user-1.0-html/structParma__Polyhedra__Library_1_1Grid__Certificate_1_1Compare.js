var structParma__Polyhedra__Library_1_1Grid__Certificate_1_1Compare =
[
    [ "operator()", "structParma__Polyhedra__Library_1_1Grid__Certificate_1_1Compare.html#a92edb0b8b1e2097c5d20795e576517cf", null ]
];