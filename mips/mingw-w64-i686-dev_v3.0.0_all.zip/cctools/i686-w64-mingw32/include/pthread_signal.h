/* Dummy header, which gets overriden, if winpthread library gets installed.  */


