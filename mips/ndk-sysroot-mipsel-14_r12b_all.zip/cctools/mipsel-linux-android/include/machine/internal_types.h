/* $OpenBSD: internal_types.h,v 1.1 2004/08/06 20:56:02 pefo Exp $ */
/* Public domain */
#ifndef _MIPS64_INTERNAL_TYPES_H_
#define _MIPS64_INTERNAL_TYPES_H_

/* Machine special type definitions */

#endif
